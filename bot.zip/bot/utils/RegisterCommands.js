const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');

module.exports = (client) => {

    console.log('Started refreshing application (/) commands.');
    
    const commands = [];
    const devCommands = [];
    const commandNames = [];

    for (const [_, command] of client.commands) {
        
        const commandData = command.data?.toJSON();
        commandData.dm_permission ??= false;

        try {
            if (!commandData) throw `No command.data found`;

            if (commandNames.includes(commandData.name)) continue;

            commandNames.push(commandData.name);

            // tout va dans DEV pour update instantané !
            commands.push(commandData);

        } catch(error) {
            console.error(`[REGISTER] Failed to register ${command.data.name}: ${error}`);
        }
    }

    if (!client.config.DEV_GUILD_ID) {
        console.warn("❌ You MUST set DEV_GUILD_ID to use instant guild commands!");
        return;
    }

    const rest = new REST({ version: '10' }).setToken(client.config.TOKEN);

    try {
        rest.put(
            Routes.applicationGuildCommands(client.config.APP_ID, client.config.DEV_GUILD_ID),
            { body: commands },
        );

        console.info('Successfully reloaded application (/) commands (guild-based).');
    } catch (error) {
        console.error(error);
    }
};
