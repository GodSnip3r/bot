const Database = require("better-sqlite3");
const db = new Database("./database.sqlite");

// Création de la table si elle n'existe pas
db.prepare(`
  CREATE TABLE IF NOT EXISTS coins (
    userId TEXT PRIMARY KEY,
    balance INTEGER NOT NULL
  )
`).run();

// 🔹 Obtenir la balance (100 coins par défaut)
function getBalance(userId) {
  const row = db
    .prepare("SELECT balance FROM coins WHERE userId = ?")
    .get(userId);

  if (!row) {
    db.prepare(
      "INSERT INTO coins (userId, balance) VALUES (?, ?)"
    ).run(userId, 100);
    return 100;
  }

  return row.balance;
}

// 🔹 Ajouter / retirer des coins
function addBalance(userId, amount) {
  const balance = getBalance(userId);
  const newBalance = balance + amount;

  db.prepare(
    "UPDATE coins SET balance = ? WHERE userId = ?"
  ).run(newBalance, userId);

  return newBalance;
}

// 🔹 Récupérer toutes les balances (pour /baltop)
function getAllBalances() {
  return db.prepare(
    "SELECT userId, balance FROM coins"
  ).all();
}

module.exports = {
  getBalance,
  addBalance,
  getAllBalances
};
