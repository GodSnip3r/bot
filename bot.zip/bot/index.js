const { Client, GatewayIntentBits, PermissionsBitField } = require("discord.js");
const mongoose = require("mongoose");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildVoiceStates
  ]
});

// Config + caches
client.config = require("./config.json");
client.cooldowns = new Map();
client.cache = new Map();

// Loaders
require("./utils/ComponentLoader.js")(client);
require("./utils/EventLoader.js")(client);
require("./utils/RegisterCommands.js")(client);

// Database (optional)
(async function () {
  if (!client.config.mongoURL) {
    return console.warn(
      "MongoDB URL is not provided in the config.json file, skipping database connection..."
    );
  }

  await mongoose.connect(client.config.mongoURL);
})();

console.log("Logging in...");
client.login(client.config.TOKEN);

// Ready
client.on("clientReady", () => {
  console.log(`Logged in as ${client.user.tag}!`);
  require("./utils/CheckIntents.js")(client);
});

// ===================================================
//  INTERACTION HANDLER CENTRALISÉ (FIXÉ)
// ===================================================
async function InteractionHandler(interaction, type) {
  const component = client[type].get(
    interaction.customId ?? interaction.commandName
  );
  if (!component) return;

  try {
    // Admin-only
    if (component.admin) {
      if (
        !interaction.member.permissions.has(
          PermissionsBitField.Flags.Administrator
        )
      ) {
        return interaction.reply({
          content: "⚠️ Only administrators can use this command!",
          flags: 64
        });
      }
    }

    // Owner-only
    if (component.owner) {
      if (interaction.user.id !== "YOURUSERID") {
        return interaction.reply({
          content: "⚠️ Only bot owners can use this command!",
          flags: 64
        });
      }
    }

    // ✅ EXECUTE SANS DEFER ICI
    await component.execute(interaction, client);

  } catch (error) {
    console.error(error);

    // ⚠️ RÉPOND SEULEMENT SI RIEN N'A ÉTÉ FAIT
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: "❌ Une erreur est survenue lors de l'exécution de la commande.",
        flags: 64
      }).catch(() => {});
    }
  }
}

// ===================================================
//  LISTENER UNIQUE
// ===================================================
client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      return InteractionHandler(interaction, "commands");
    }

    if (interaction.isButton()) {
      return InteractionHandler(interaction, "buttons");
    }

    if (interaction.isStringSelectMenu()) {
      return InteractionHandler(interaction, "dropdowns");
    }

    if (interaction.isModalSubmit()) {
      return InteractionHandler(interaction, "modals");
    }

  } catch (err) {
    console.error("Error handling interaction:", err);
  }
});
