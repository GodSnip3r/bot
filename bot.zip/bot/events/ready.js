const { ActivityType } = require('discord.js');

module.exports = {
    name: 'clientReady', 
    once: true,
    async execute(client) { 
        client.user.setActivity({
            name: 'IM scamming people right now',
            type: ActivityType.Custom,
         //   url: 'https://www.enfinlibre.com/canada/?h_ga_id=136479278823&gbraid=0AAAAACmZMvnUex31hJaqyTIhdRb0_v6O8&h_ad_id=604375729868&gad_source=1&gad_campaignid=17506214143&h_keyword=enfin+libre+formation&h_placement=&h_keyword_id=kwd-1588313170021&gc_id=17506214143'
        });
    },
};

const { getBalance } = require("../utils/coins");

module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    client.guilds.cache.forEach(guild => {
      guild.members.fetch().then(members => {
        members.forEach(member => {
          if (!member.user.bot) {
            getBalance(member.id);
          }
        });
      });
    });
  }
};
