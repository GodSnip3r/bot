const { SlashCommandBuilder } = require("discord.js");
const { getAllBalances } = require("../utils/coins");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("baltop")
    .setDescription("Voir le top 5 des plus riches du serveur"),

  async execute(interaction) {
    // 👇 TRÈS IMPORTANT
    await interaction.deferReply();

    const balances = getAllBalances();
    const guild = interaction.guild;

    const members = await guild.members.fetch();
    const leaderboard = [];

    for (const [userId, balance] of balances) {
      if (members.has(userId)) {
        leaderboard.push({ userId, balance });
      }
    }

    if (leaderboard.length === 0) {
      return interaction.editReply("😕 Personne n’a encore de coins.");
    }

    leaderboard.sort((a, b) => b.balance - a.balance);

    const top5 = leaderboard.slice(0, 5);

    let message = "🏆 **Top 5 des plus riches** 🏆\n\n";

    for (let i = 0; i < top5.length; i++) {
      const user = await interaction.client.users.fetch(top5[i].userId);
      message += `**${i + 1}.** ${user.username} — 💰 ${top5[i].balance} coins\n`;
    }

    interaction.editReply(message);
  }
};
