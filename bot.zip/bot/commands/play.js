const { SlashCommandBuilder } = require("discord.js");
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus
} = require("@discordjs/voice");
const playdl = require("play-dl");

function respond(interaction, content) {
  if (interaction.deferred || interaction.replied) {
    return interaction.editReply(content).catch(() => {});
  } else {
    return interaction.reply(content).catch(() => {});
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("play")
    .setDescription("Joue une musique")
    .addStringOption(option =>
      option
        .setName("song")
        .setDescription("Nom de la chanson")
        .setRequired(true)
    ),

  async execute(interaction) {
    const query = interaction.options.getString("song");
    const voiceChannel = interaction.member.voice.channel;

    if (!voiceChannel) {
      return respond(interaction, "❌ Tu dois être en vocal.");
    }

    try {
      console.log("[PLAY] Recherche :", query);

      const results = await playdl.search(query, {
        limit: 1,
        source: { youtube: "video" }
      });

      if (!results.length) {
        return respond(interaction, "❌ Aucun résultat.");
      }

      const video = results[0];
      const videoUrl = `https://www.youtube.com/watch?v=${video.id}`;

      console.log("[PLAY] Trouvé :", video.title);
      console.log("[PLAY] URL :", videoUrl);

      const connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: interaction.guild.id,
        adapterCreator: interaction.guild.voiceAdapterCreator
      });

      // 🔥 FIX CRITIQUE ICI
      const info = await playdl.video_basic_info(videoUrl);
      const stream = await playdl.stream_from_info(info);

      const player = createAudioPlayer();
      const resource = createAudioResource(stream.stream, {
        inputType: stream.type
      });

      player.play(resource);
      connection.subscribe(player);

      player.on(AudioPlayerStatus.Playing, () => {
        console.log("[PLAY] ▶️ Lecture OK");
      });

      player.on(AudioPlayerStatus.Idle, () => {
        console.log("[PLAY] ⏹️ Fin");
        connection.destroy();
      });

      player.on("error", err => {
        console.error("[PLAY] ❌ Player error:", err);
      });

      return respond(interaction, `🎶 **Lecture :** ${video.title}`);

    } catch (err) {
      console.error("[PLAY] ❌ Erreur:", err);
      return respond(interaction, "❌ Impossible de lire cette vidéo.");
    }
  }
};
