const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { addBalance } = require("../utils/coins");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("addmoney")
    .setDescription("Ajouter des coins à un joueur")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(opt =>
      opt.setName("joueur")
        .setDescription("Le joueur")
        .setRequired(true)
    )
    .addIntegerOption(opt =>
      opt.setName("montant")
        .setDescription("Nombre de coins à ajouter")
        .setRequired(true)
    ),

  async execute(interaction) {
    const user = interaction.options.getUser("joueur");
    const montant = interaction.options.getInteger("montant");

    addBalance(user.id, montant);

    interaction.reply(`✅ **${montant} coins** ajoutés à ${user.username}`);
  }
};
