const { SlashCommandBuilder } = require("discord.js");
const { getBalance, addBalance } = require("../utils/coins");


module.exports = {
  data: new SlashCommandBuilder()
    .setName("coinflip")
    .setDescription("Pile ou face")
    .addStringOption(opt =>
      opt.setName("choix")
        .setDescription("pile ou face")
        .setRequired(true)
        .addChoices(
          { name: "pile", value: "pile" },
          { name: "face", value: "face" }
        ))
    .addIntegerOption(opt =>
      opt.setName("mise")
        .setDescription("Nombre de coins")
        .setRequired(true)
    ),

  async execute(interaction) {
    const choix = interaction.options.getString("choix");
    const mise = interaction.options.getInteger("mise");
    const userId = interaction.user.id;

    if (mise <= 0) {
      return interaction.reply({ content: "❌ Mise invalide", ephemeral: true });
    }

    const balance = getBalance(userId);
    if (balance < mise) {
      return interaction.reply({ content: "💸 Tu n’as pas assez de coins", ephemeral: true });
    }

    const resultat = Math.random() < 0.5 ? "pile" : "face";

    if (choix === resultat) {
      addBalance(userId, mise);
      interaction.reply(`🪙 **${resultat}** ! Tu gagnes **${mise} coins** 🎉`);
    } else {
      addBalance(userId, -mise);
      interaction.reply(`🪙 **${resultat}** ! Tu perds **${mise} coins** 😭`);
    }
  }
};
