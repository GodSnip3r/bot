const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("gay")
    .setDescription("Calcule ton pourcentage de gayness 🌈")
    .addStringOption(option =>
      option
        .setName("nom")
        .setDescription("Entre un nom ou un pseudo")
        .setRequired(true)
    ),
  async execute(interaction) {
    const name = interaction.options.getString("nom");
    const lowerName = name.toLowerCase();

    if (["desro","caleb","Desrosiers", "eric"].includes(lowerName)) {
      return interaction.reply(`🤣 ${name}, pas besoin de test grosse tapette`);
    }

    if (["oli", "olivier"].includes(lowerName)) {
      return interaction.reply(`😎 ${name}, tu es **0% gay** (hétéro légendaire) 🏆`);
    }

    const pourcentage = Math.floor(Math.random() * 101);

    let message = `${name}, tu es **${pourcentage}% gay** 🌈`;

    if (pourcentage === 0) {
      message = `😱 ${name}, incroyable… tu es **0% gay** ! Tu es hétéro certifié ISO 9001 🏆`;
    } else if (pourcentage === 100) {
      message = `🌈🔥 ${name}, félicitations ! Tu es **100% gay** ! Tu gagnes la couronne LGBTQ+ 👑🏳️‍🌈 , S/O Emile chabot`;
    } else if (pourcentage === 50) {
      message = `🤔 ${name}, pile au milieu… **50% gay** ! T’es officiellement bi-curieux , ou juste trop fiffou pour choisir 🏳️‍🌈`;
    }

    await interaction.reply(message);
  },
};
