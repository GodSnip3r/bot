const { SlashCommandBuilder } = require("discord.js");
const { getBalance } = require("../utils/coins");


module.exports = {
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Voir ton nombre de coins"),

  async execute(interaction) {
    const balance = getBalance(interaction.user.id);
    interaction.reply(`💰 Tu as **${balance} coins**`);
  }
};
